# constants.py

ERROR_MSG = "ERROR"